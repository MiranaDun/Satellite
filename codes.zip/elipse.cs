using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class elipse : MonoBehaviour
{
    [SerializeField]
    Transform center;


    [SerializeField]
    float radius = 30f, angularspeed = 2f;

    float positionX, positionY, angle = 90f;

    void Update()
    {
        positionX = center.position.x + Mathf.Cos(angle+10) * radius;
        positionY = center.position.y + Mathf.Sin(angle) * radius;
        transform.position = new Vector2(positionX, positionY);
        angle = angle + Time.deltaTime * angularspeed;

        if (angle >= 360f)
        {
            angle = 0f;
        }
    }
}
